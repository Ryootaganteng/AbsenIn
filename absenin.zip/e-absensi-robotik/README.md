# E-Absensi Robotik

Web absensi mobile-first dengan tema premium putih-oranye.

## File utama
- `index.html` — login ID unik
- `dashboard-siswa.html` — dashboard anggota, scan QR, riwayat, pengajuan izin
- `dashboard-pengurus.html` — sesi QR, verifikasi izin, kas, tambah anggota, ekspor CSV
- `verifikasi.html` — layar QR untuk proyektor/laptop
- `styles.css`, `app.js` — tampilan dan logika aplikasi
- `Code.gs` — contoh backend Google Apps Script untuk dikembangkan

## Demo lokal
Buka `index.html` melalui local server (disarankan VS Code Live Server atau `python -m http.server 8000`). Login demo:
- `SISWA024` untuk anggota
- `ADMIN001` untuk pengurus

Demo menyimpan data ke `localStorage` browser. Ini berguna untuk uji tampilan dan alur pada satu browser, **bukan database bersama**. Login demo tidak aman untuk produksi.

## Cara pakai alur QR demo
1. Login sebagai `ADMIN001`.
2. Masukkan latitude dan longitude lokasi kegiatan yang sebenarnya.
3. Tekan **Buka layar QR**. Layar QR akan menampilkan token yang berotasi setiap 30 detik.
4. Di browser/perangkat anggota, login `SISWA024`, pilih **Scan QR absensi**, izinkan kamera dan lokasi, lalu pindai QR dari layar pengurus.
5. Untuk demo lintas perangkat, `localStorage` tidak tersinkron; diperlukan backend. Jangan gunakan demo ini sebagai sistem kehadiran resmi sebelum backend dipasang.

## Batasan keamanan penting
- Token demo dibuat di browser, jadi belum tahan terhadap pemalsuan/rekayasa klien.
- Radius 50 m memakai koordinat browser; GPS dapat meleset dan lokasi browser bisa dimanipulasi.
- QR image menggunakan layanan QR pihak ketiga via internet.
- Jangan memasukkan data pribadi nyata sampai autentikasi dan backend dikonfigurasi.

## Deployment
Untuk uji tampilan, unggah folder ini ke Vercel sebagai static site. Kamera/geolocation umumnya membutuhkan HTTPS (Vercel menyediakan HTTPS). Sebelum digunakan sungguhan, siapkan Google Sheet, deploy Apps Script sebagai Web App, dan pindahkan autentikasi, token QR, pemeriksaan radius, pencatatan hadir, izin, dan kas ke server. Jangan menyimpan secret/API key di frontend.
